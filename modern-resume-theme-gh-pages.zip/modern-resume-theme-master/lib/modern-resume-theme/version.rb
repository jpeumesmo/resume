module ModernResumeTheme
  VERSION = "1.8.8"
end
